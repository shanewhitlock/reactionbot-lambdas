const { WebClient } = require('@slack/web-api');

exports.handler =  async (event, context) => {
    const response = {
        statusCode: null,
        body: null,
    };
    const web = new WebClient(process.env.SLACK_TOKEN);
    const currentTime = new Date().toTimeString();
    console.log("EVENT: \n" + JSON.stringify(event, null, 2))
    try {
        // Use the `chat.postMessage` method to send a message from this app
        await web.chat.postMessage({
          channel: '#general',
          text: `Hello Lior!!! The current time is ${currentTime}`,
        });
        response.statusCode = 200;
        response.body = "Posted message!"
      } catch (error) {
        response.statusCode = 500;
        response.body = "Failed to Post message!"
      }

    return response;
  }